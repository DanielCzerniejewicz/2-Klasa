﻿using System;
using ConsoleApplication2.Klasy;

namespace ConsoleApplication2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}